module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        mint: {
          50: '#f2fdf7',
          100: '#dffaf0',
          200: '#bff3db',
          500: '#8ee0b8'
        }
      }
    }
  },
  plugins: [],
}
