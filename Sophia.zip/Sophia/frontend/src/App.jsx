import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Ledger from './pages/Ledger'
import Students from './pages/Students'
import Classes from './pages/Classes'
import Teachers from './pages/Teachers'
import Payroll from './pages/Payroll'
import Layout from './components/Layout'

function App(){
  return (
    <Routes>
      <Route path="/login" element={<Login/>} />
      <Route path="/" element={<Layout/>}>
        <Route index element={<Dashboard/>} />
        <Route path="ledger" element={<Ledger/>} />
        <Route path="students" element={<Students/>} />
        <Route path="classes" element={<Classes/>} />
        <Route path="teachers" element={<Teachers/>} />
        <Route path="payroll" element={<Payroll/>} />
      </Route>
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  )
}

export default App
