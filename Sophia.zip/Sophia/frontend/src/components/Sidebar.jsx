import React from 'react'
import { NavLink } from 'react-router-dom'

const items = [
  {to:'/', label:'Dashboard'},
  {to:'/ledger', label:'Ledger'},
  {to:'/students', label:'Students'},
  {to:'/classes', label:'Classes'},
  {to:'/teachers', label:'Teachers'},
  {to:'/payroll', label:'Payroll'},
  {to:'#', label:'Reports (Coming soon)'},
  {to:'#', label:'Settings (Coming soon)'}
]

export default function Sidebar(){
  return (
    <div className="w-64 bg-white border-r p-4">
      <div className="mb-6 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">🌱</div>
        <div>
          <div className="font-bold">SOPHIA</div>
          <div className="text-xs text-gray-500">Kindergarten Admin</div>
        </div>
      </div>
      <nav className="flex flex-col gap-1">
        {items.map(i=> (
          <NavLink key={i.label} to={i.to} className={({isActive})=> `p-2 rounded ${isActive? 'bg-emerald-50':''}`}>{i.label}</NavLink>
        ))}
      </nav>
    </div>
  )
}
