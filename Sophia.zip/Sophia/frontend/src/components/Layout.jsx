import React from 'react'
import { Outlet, Link, useLocation } from 'react-router-dom'
import Header from './Header'
import Sidebar from './Sidebar'

export default function Layout(){
  const loc = useLocation();
  return (
    <div className="min-h-screen flex">
      <Sidebar />
      <div className="flex-1">
        <Header title={loc.pathname.replace('/','') || 'Dashboard'} />
        <div className="p-6">
          <Outlet />
        </div>
      </div>
    </div>
  )
}
