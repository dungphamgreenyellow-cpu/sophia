import React from 'react'

function nowBadge(){
  const d = new Date();
  return `${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
}

export default function Header({title='Dashboard'}){
  return (
    <div className="h-14 bg-white flex items-center justify-between px-4 border-b">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">🌱</div>
        <div>
          <div className="font-bold">SOPHIA <span className="text-sm text-gray-500">Kindergarten Admin System</span></div>
        </div>
      </div>
      <div className="text-lg font-medium">{title}</div>
      <div className="flex items-center gap-3">
        <div className="px-2 py-1 bg-emerald-50 rounded">{nowBadge()}</div>
        <div className="px-3 py-1 bg-gray-100 rounded">admin</div>
        <button className="px-3 py-1 bg-red-50 text-red-600 rounded">Logout</button>
      </div>
    </div>
  )
}
