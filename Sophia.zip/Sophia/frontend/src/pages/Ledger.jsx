import React, {useEffect, useState} from 'react'
import api from '../utils/api'

export default function Ledger(){
  const [rows,setRows] = useState([]);
  const [form,setForm] = useState({id:null, date:new Date().toISOString(), type:'thu', category:'Thu học phí', amount:0, note:''});
  useEffect(()=> load(),[]);
  const load = async ()=>{ const r = await api.get('/ledger'); setRows(r.data) }
  const save = async ()=>{
    if (form.id) {
      await api.put(`/ledger/${form.id}`, form);
    } else {
      await api.post('/ledger', form);
    }
    setForm({id:null, date:new Date().toISOString(), type:'thu', category:'Thu học phí', amount:0, note:''});
    load()
  }
  const del = async (id)=>{ await api.delete(`/ledger/${id}`); if (form.id===id) setForm({id:null, date:new Date().toISOString(), type:'thu', category:'Thu học phí', amount:0, note:''}); load() }
  const edit = (r)=>{ setForm({ id: r.id, date: r.date, type: r.type, category: r.category, amount: Math.abs(r.amount), note: r.note }) }
  return (
    <div>
      <div className="mb-4 p-4 bg-white rounded">
        <div className="font-bold mb-2">Thêm giao dịch</div>
        <div className="flex gap-2">
          <select className="p-2 border" value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option value="thu">THU (+)</option><option value="chi">CHI (-)</option></select>
          <select className="p-2 border" value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option>Thu học phí</option><option>Chi lương</option><option>Chi vận hành</option><option>Khác</option></select>
          <input type="number" className="p-2 border" value={form.amount} onChange={e=>setForm({...form,amount:parseInt(e.target.value||0)})} />
          <button className="px-3 bg-emerald-500 text-white rounded" onClick={save}>Lưu</button>
        </div>
      </div>
      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50"><tr><th className="p-2">Date</th><th>Type</th><th>Category</th><th>Amount</th><th>Note</th><th></th></tr></thead>
          <tbody>
            {rows.map(r=> (
              <tr key={r.id} className="border-t"><td className="p-2">{r.date}</td><td>{r.type}</td><td>{r.category}</td><td className={r.amount>0? 'text-green-600':'text-pink-600'}>{r.amount}</td><td>{r.note}</td><td className="flex gap-2"><button className="text-blue-600" onClick={()=>edit(r)}>Sửa</button><button className="text-red-600" onClick={()=>del(r.id)}>Xóa</button></td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
