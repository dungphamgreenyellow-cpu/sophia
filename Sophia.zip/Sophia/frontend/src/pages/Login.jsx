import React, {useState} from 'react'
import api from '../utils/api'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [username,setUsername] = useState('admin');
  const [password,setPassword] = useState('admin123');
  const nav = useNavigate();
  const [err,setErr] = useState(null);
  const submit = async (e)=>{
    e.preventDefault();
    try{
      await api.post('/login', { username, password });
      nav('/');
    }catch(e){ setErr('Login failed') }
  }
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-full max-w-md bg-white p-6 rounded shadow">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">🌱</div>
          <div>
            <div className="text-xl font-bold">SOPHIA</div>
            <div className="text-xs text-gray-500">Kindergarten Admin System</div>
          </div>
        </div>
        <form onSubmit={submit}>
          <input className="w-full p-2 border rounded mb-2" value={username} onChange={e=>setUsername(e.target.value)} />
          <input type="password" className="w-full p-2 border rounded mb-2" value={password} onChange={e=>setPassword(e.target.value)} />
          {err && <div className="text-red-600 mb-2">{err}</div>}
          <button className="w-full py-2 bg-emerald-500 text-white rounded">Login</button>
        </form>
      </div>
    </div>
  )
}
