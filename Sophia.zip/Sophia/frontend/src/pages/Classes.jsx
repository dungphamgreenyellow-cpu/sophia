import React, {useEffect, useState} from 'react'
import api from '../utils/api'

export default function Classes(){
  const [rows,setRows]=useState([]);
  const [teachers,setTeachers]=useState([]);
  const [form,setForm]=useState({name:'', teacher_ids:[]});
  const [expanded,setExpanded]=useState({});
  useEffect(()=> { load(); loadTeachers(); },[]);
  const load=async()=>{ const r=await api.get('/classes'); setRows(r.data) }
  const loadTeachers=async()=>{ const r = await api.get('/teachers'); setTeachers(r.data) }
  const add=async()=>{ await api.post('/classes', form); setForm({name:'',teacher_ids:[]}); load() }
  const toggleTeacher = (id)=>{
    let arr = form.teacher_ids || [];
    if (arr.includes(id)) arr = arr.filter(x=>x!==id); else arr = [...arr, id].slice(0,3);
    setForm({...form, teacher_ids: arr});
  }
  const showStudents = async (id)=>{
    if (expanded[id]) { setExpanded({...expanded, [id]: null}); return }
    const r = await api.get(`/classes/${id}/students`);
    setExpanded({...expanded, [id]: r.data});
  }
  return (
    <div>
      <div className="mb-4 p-4 bg-white rounded">
        <div className="font-bold mb-2">Thêm lớp</div>
        <div className="flex gap-2 items-center">
          <input className="p-2 border" placeholder="Tên lớp" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
          <div className="flex gap-1 items-center">
            {teachers.map(t=> (
              <button key={t.id} className={`px-2 py-1 border rounded ${form.teacher_ids.includes(t.id)? 'bg-emerald-50':''}`} onClick={()=>toggleTeacher(t.id)}>{t.full_name}</button>
            ))}
          </div>
          <button className="px-3 bg-emerald-500 text-white rounded" onClick={add}>Thêm lớp mới</button>
        </div>
      </div>
      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50"><tr><th>Tên</th><th>Giáo viên</th><th>Sĩ số</th></tr></thead>
          <tbody>
            {rows.map(r=> (
              <React.Fragment key={r.id}>
                <tr className="border-t cursor-pointer" onClick={()=>showStudents(r.id)}><td className="p-2">{r.name}</td><td>{(r.teacher_ids||[]).length}</td><td>{r.size}</td></tr>
                {expanded[r.id] && (
                  <tr><td colSpan={3} className="p-2 bg-gray-50">
                    <div className="font-semibold mb-2">Students</div>
                    <ul>
                      {expanded[r.id].map(s=> <li key={s.id}>{s.full_name} ({s.status})</li>)}
                    </ul>
                  </td></tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
