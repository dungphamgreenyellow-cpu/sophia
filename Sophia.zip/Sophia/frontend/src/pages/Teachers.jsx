import React, {useEffect, useState} from 'react'
import api from '../utils/api'

export default function Teachers(){
  const [rows,setRows]=useState([]);
  const [form,setForm]=useState({full_name:'', dob:'', phone:''});
  useEffect(()=> load(),[]);
  const load=async()=>{ const r = await api.get('/teachers'); setRows(r.data) }
  const add=async()=>{ await api.post('/teachers', form); setForm({full_name:'', dob:'', phone:''}); load() }
  return (
    <div>
      <div className="mb-4 p-4 bg-white rounded">
        <div className="font-bold mb-2">Thêm giáo viên</div>
        <div className="flex gap-2">
          <input className="p-2 border" placeholder="Full name" value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} />
          <input className="p-2 border" type="date" value={form.dob} onChange={e=>setForm({...form,dob:e.target.value})} />
          <input className="p-2 border" placeholder="Phone" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} />
          <button className="px-3 bg-emerald-500 text-white rounded" onClick={add}>Thêm</button>
        </div>
      </div>
      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50"><tr><th>Full name</th><th>Phone</th><th>Start</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map(r=> (<tr key={r.id} className="border-t"><td className="p-2">{r.full_name}</td><td>{r.phone}</td><td>{r.start_date}</td><td>{r.status}</td></tr>))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
