import React, {useEffect, useState, useRef} from 'react'
import api from '../utils/api'

export default function Payroll(){
  const [rows,setRows]=useState([]);
  const [form,setForm]=useState({teacher_id:'', month:'', basic:0, allowance:0, bonus:0, deduction:0, overtime:0, other:0});
  useEffect(()=> load(),[]);
  const load=async()=>{ const month = new Date(); month.setMonth(month.getMonth()-1); const m = month.toISOString().slice(0,7); const r = await api.get(`/payroll?month=${m}`); setRows(r.data) }
  const upsert=async(id)=>{
    const payload = { ...form, net: (form.basic||0) + (form.allowance||0) + (form.bonus||0) - (form.deduction||0) + (form.overtime||0) + (form.other||0), id: id || require('uuid').v4() };
    await api.put(`/payroll/${payload.id}`, payload);
    load();
  }
  const debounceRef = useRef(null);
  useEffect(()=>{
    // auto-save when teacher_id present, debounce 1000ms
    if (!form.teacher_id) return;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(()=>{
      upsert(form.id);
    }, 1000);
    return ()=> clearTimeout(debounceRef.current);
  }, [form]);
  return (
    <div>
      <div className="mb-4 p-4 bg-white rounded">
        <div className="font-bold mb-2">Payroll (auto-create Ledger Chi lương)</div>
        <div className="flex gap-2">
          <input className="p-2 border" placeholder="Teacher ID" value={form.teacher_id} onChange={e=>setForm({...form,teacher_id:e.target.value})} />
          <input className="p-2 border" type="month" value={form.month} onChange={e=>setForm({...form,month:e.target.value})} />
          <input className="p-2 border" type="number" value={form.basic} onChange={e=>setForm({...form,basic:parseInt(e.target.value||0)})} />
          <button className="px-3 bg-emerald-500 text-white rounded" onClick={()=>upsert()}>Save Payroll</button>
        </div>
      </div>
      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50"><tr><th>Teacher</th><th>Month</th><th>Net</th></tr></thead>
          <tbody>
            {rows.map(r=> (<tr key={r.id} className="border-t"><td className="p-2">{r.teacher_id}</td><td>{r.month}</td><td className={r.net>0? 'text-green-600':'text-pink-600'}>{r.net}</td></tr>))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
