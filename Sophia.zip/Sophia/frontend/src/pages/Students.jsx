import React, {useEffect, useState} from 'react'
import api from '../utils/api'

export default function Students(){
  const [rows,setRows]=useState([]);
  const [form,setForm]=useState({full_name:'', dob:'', enroll_date:''});
  useEffect(()=> load(),[]);
  const load=async()=>{ const r = await api.get('/students'); setRows(r.data) }
  const add=async()=>{ await api.post('/students', form); setForm({full_name:'', dob:'', enroll_date:''}); load() }
  return (
    <div>
      <div className="mb-4 p-4 bg-white rounded">
        <div className="font-bold mb-2">Thêm học sinh</div>
        <div className="flex gap-2">
          <input className="p-2 border" placeholder="Full name" value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} />
          <input className="p-2 border" type="date" value={form.dob} onChange={e=>setForm({...form,dob:e.target.value})} />
          <input className="p-2 border" type="date" value={form.enroll_date} onChange={e=>setForm({...form,enroll_date:e.target.value})} />
          <button className="px-3 bg-emerald-500 text-white rounded" onClick={add}>Thêm</button>
        </div>
      </div>
      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50"><tr><th>Full name</th><th>DoB</th><th>Enroll</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map(r=> (<tr key={r.id} className="border-t"><td className="p-2">{r.full_name}</td><td>{r.dob}</td><td>{r.enroll_date}</td><td>{r.status}</td></tr>))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
