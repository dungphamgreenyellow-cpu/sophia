import React, {useEffect, useState} from 'react'
import api from '../utils/api'

export default function Dashboard(){
  const [data,setData] = useState(null);
  useEffect(()=>{ api.get('/dashboard').then(r=> setData(r.data)).catch(()=>{}) },[])
  if (!data) return <div>Loading...</div>
  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="p-4 bg-white rounded shadow">
        <div className="font-bold">Tổng quan vận hành</div>
        <div className="mt-2">Lớp: {data.classesCount}</div>
        <div>HS đang học: {data.studentsCount}</div>
        <div>GV: {data.teachersCount}</div>
      </div>
      <div className="p-4 bg-white rounded shadow">
        <div className="font-bold">Biến động HS tháng này</div>
        <div>Vào mới: {data.joined}</div>
        <div>Nghỉ: {data.left}</div>
      </div>
      <div className="p-4 bg-white rounded shadow">
        <div className="font-bold">Tài chính</div>
        <div className="text-green-600">Thu: {data.totalThu}</div>
        <div className="text-pink-600">Chi: {data.totalChi}</div>
        <div>Lãi/Lỗ: {data.profit}</div>
      </div>
    </div>
  )
}
