const API = 'http://localhost:8080/api';

async function req(path, opts={}){
  const res = await fetch(API+path, { credentials: 'include', headers: {'Content-Type':'application/json'}, ...opts});
  if (!res.ok) throw new Error('API');
  return res.json();
}

export default {
  post: (path, body) => req(path, { method: 'POST', body: JSON.stringify(body) }),
  get: (path) => req(path, { method: 'GET' }),
  put: (path, body) => req(path, { method: 'PUT', body: JSON.stringify(body) }),
  delete: (path) => req(path, { method: 'DELETE' })
}
