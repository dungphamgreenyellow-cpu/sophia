let bcrypt;
try { bcrypt = require('bcrypt'); } catch (e) { bcrypt = null; }
const db = require('./db');
let uuidv4;
try { uuidv4 = require('uuid').v4; } catch (e) { uuidv4 = () => (Date.now().toString(36) + Math.random().toString(36).slice(2)); }

async function seed() {
  const username = 'admin';
  const existing = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (existing) {
    console.log('Admin already exists');
    return;
  }
  const id = uuidv4();
  let hash;
  if (bcrypt) {
    hash = await bcrypt.hash('admin123', 10);
  } else {
    console.warn('bcrypt not available, seeding with plaintext password for development');
    hash = 'admin123';
  }
  db.prepare('INSERT INTO users (id, username, password, role, full_name) VALUES (?, ?, ?, ?, ?)')
    .run(id, username, hash, 'admin', 'Administrator');
  console.log('Seeded admin user: admin / admin123');
}

seed().catch(console.error);
