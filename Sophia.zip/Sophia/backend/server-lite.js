const http = require('http');
const url = require('url');
const db = require('./db');

const PORT = process.env.PORT || 8080;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'http://localhost:3000';

function sendJSON(res, obj, status=200) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': FRONTEND_ORIGIN,
    'Access-Control-Allow-Credentials': 'true'
  });
  res.end(body);
}

const server = http.createServer((req, res) => {
  const parsed = url.parse(req.url, true);
  const { pathname, query } = parsed;

  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': FRONTEND_ORIGIN,
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  if (req.method === 'GET' && pathname === '/api/dashboard') {
    try {
      const classesCount = db.prepare('SELECT COUNT(*) as c FROM classes').get().c || 0;
      const studentsCount = db.prepare('SELECT COUNT(*) as c FROM students WHERE status = "active"').get().c || 0;
      const teachersCount = db.prepare('SELECT COUNT(*) as c FROM teachers WHERE status = "active"').get().c || 0;

      const now = new Date();
      const y = now.getFullYear();
      const m = String(now.getMonth()+1).padStart(2,'0');
      const monthPrefix = `${y}-${m}`;
      const joined = db.prepare('SELECT COUNT(*) as c FROM students WHERE enroll_date LIKE ?').get(`${monthPrefix}%`).c || 0;
      const left = db.prepare('SELECT COUNT(*) as c FROM students WHERE exit_date LIKE ?').get(`${monthPrefix}%`).c || 0;

      const totalThu = db.prepare('SELECT SUM(amount) as s FROM ledger WHERE amount > 0').get().s || 0;
      const totalChi = db.prepare('SELECT SUM(amount) as s FROM ledger WHERE amount < 0').get().s || 0;
      const profit = totalThu + totalChi;

      return sendJSON(res, { success: true, data: { classesCount, studentsCount, teachersCount, joined, left, totalThu, totalChi, profit } });
    } catch (e) {
      return sendJSON(res, { success: false, error: String(e) }, 500);
    }
  }

  if (req.method === 'GET' && pathname === '/api/ledger') {
    try {
      const rows = db.prepare('SELECT * FROM ledger ORDER BY date DESC, id DESC').all();
      return sendJSON(res, { success: true, data: rows });
    } catch (e) {
      return sendJSON(res, { success: false, error: String(e) }, 500);
    }
  }

  // unknown
  sendJSON(res, { success: false, error: 'Not found' }, 404);
});

server.listen(PORT, () => {
  console.log(`SOPHIA lite backend listening on http://localhost:${PORT}`);
});
