let db;
try {
  const Database = require('better-sqlite3');
  const fs = require('fs');
  const path = require('path');

  const DB_DIR = path.join(__dirname, 'db');
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  const DB_PATH = path.join(DB_DIR, 'db.sqlite');

  db = new Database(DB_PATH);
  // Create tables if not exist
  db.pragma('journal_mode = WAL');

  db.prepare(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT,
    full_name TEXT
  )`).run();

  db.prepare(`CREATE TABLE IF NOT EXISTS ledger (
    id TEXT PRIMARY KEY,
    date TEXT,
    type TEXT,
    category TEXT,
    amount INTEGER,
    note TEXT,
    payroll_item_id TEXT
  )`).run();

  db.prepare(`CREATE TABLE IF NOT EXISTS students (
    id TEXT PRIMARY KEY,
    full_name TEXT,
    last_name TEXT,
    dob TEXT,
    enroll_date TEXT,
    exit_date TEXT,
    class_id TEXT,
    status TEXT,
    parent1_name TEXT,
    parent1_relation TEXT,
    parent1_phone TEXT,
    parent1_address TEXT,
    parent2_name TEXT,
    parent2_relation TEXT,
    parent2_phone TEXT,
    parent2_address TEXT
  )`).run();

  db.prepare(`CREATE TABLE IF NOT EXISTS teachers (
    id TEXT PRIMARY KEY,
    full_name TEXT,
    last_name TEXT,
    dob TEXT,
    phone TEXT,
    start_date TEXT,
    status TEXT
  )`).run();

  db.prepare(`CREATE TABLE IF NOT EXISTS classes (
    id TEXT PRIMARY KEY,
    name TEXT,
    teacher_ids TEXT
  )`).run();

  db.prepare(`CREATE TABLE IF NOT EXISTS payroll (
    id TEXT PRIMARY KEY,
    teacher_id TEXT,
    month TEXT,
    basic INTEGER,
    allowance INTEGER,
    bonus INTEGER,
    deduction INTEGER,
    overtime INTEGER,
    other INTEGER,
    net INTEGER
  )`).run();
} catch (err) {
  // Fallback in-memory DB to allow running without native modules
  console.warn('better-sqlite3 not available, using in-memory DB stub for development.');
  let uuid;
  try { uuid = require('uuid'); } catch (e) { uuid = { v4: () => (Date.now().toString(36) + Math.random().toString(36).slice(2)) }; }
  const tables = {
    users: [],
    ledger: [],
    students: [],
    teachers: [],
    classes: [],
    payroll: []
  };

  const makeStmt = (sql) => {
    const sl = sql.trim();
    return {
      run: function(...args) {
        // INSERT INTO ledger ... VALUES (?, ?, ?, ?, ?, ?, ?)
        if (/INSERT INTO ledger/i.test(sl)) {
          const [id, date, type, category, amount, note, payroll_item_id] = args;
          tables.ledger.push({ id, date, type, category, amount, note, payroll_item_id });
          return { changes: 1 };
        }
        // INSERT INTO users ... VALUES (?, ?, ?, ?, ?)
        if (/INSERT INTO users/i.test(sl)) {
          const [id, username, password, role, full_name] = args;
          tables.users.push({ id, username, password, role, full_name });
          return { changes: 1 };
        }
        // UPDATE ledger SET ... WHERE id=?
        if (/UPDATE ledger SET/i.test(sl)) {
          const [date, type, category, amount, note, id] = args;
          const r = tables.ledger.find(x => x.id === id);
          if (r) {
            r.date = date; r.type = type; r.category = category; r.amount = amount; r.note = note;
            return { changes: 1 };
          }
          return { changes: 0 };
        }
        // DELETE FROM ledger WHERE id=?
        if (/DELETE FROM ledger WHERE id=\?/i.test(sl)) {
          const [id] = args;
          const len = tables.ledger.length;
          tables.ledger = tables.ledger.filter(x => x.id !== id);
          return { changes: len - tables.ledger.length };
        }
        // CREATE TABLE - ignore
        return { changes: 0 };
      },
      get: function(param) {
        // COUNT queries
        if (/SELECT COUNT\(\*\) as c FROM (\w+)/i.test(sl)) {
          const m = sl.match(/SELECT COUNT\(\*\) as c FROM (\w+)( WHERE (.*))?/i);
          if (!m) return { c: 0 };
          const table = m[1];
          const where = m[3];
          if (where && /status = "active"/i.test(where)) {
            return { c: tables[table].filter(x => x.status === 'active').length };
          }
          return { c: tables[table].length };
        }
        // SUM amount queries
        if (/SELECT SUM\(amount\) as s FROM ledger WHERE amount > 0/i.test(sl)) {
          const s = tables.ledger.filter(x => x.amount > 0).reduce((a,b)=>a+b.amount||a,0);
          return { s };
        }
        if (/SELECT SUM\(amount\) as s FROM ledger WHERE amount < 0/i.test(sl)) {
          const s = tables.ledger.filter(x => x.amount < 0).reduce((a,b)=>a+b.amount||a,0);
          return { s };
        }
        // LIKE ? for enroll_date/exit_date
        if (/SELECT COUNT\(\*\) as c FROM (\w+) WHERE (\w+) LIKE \?/i.test(sl)) {
          const m = sl.match(/FROM (\w+) WHERE (\w+) LIKE \?/i);
          const table = m[1];
          const col = m[2];
          const prefix = param || '';
          return { c: tables[table].filter(x => (x[col]||'').startsWith(prefix.replace('%',''))).length };
        }
        // SELECT * FROM users WHERE username = ?
        if (/SELECT \* FROM users WHERE username = \?/i.test(sl)) {
          const username = param;
          return tables.users.find(u => u.username === username) || null;
        }
        // SELECT * FROM users WHERE id = ?
        if (/SELECT \* FROM (\w+) WHERE id = \?/i.test(sl)) {
          const m = sl.match(/SELECT \* FROM (\w+) WHERE id = \?/i);
          const table = m[1];
          const id = param;
          return (tables[table] || []).find(x => x.id === id) || null;
        }
        return {};
      },
      all: function() {
        if (/SELECT \* FROM ledger/i.test(sl)) {
          return tables.ledger.slice().sort((a,b)=> (b.date.localeCompare(a.date)|| b.id.localeCompare(a.id)));
        }
        return [];
      }
    };
  };

  db = {
    prepare: (sql) => makeStmt(sql)
  };
}

module.exports = db;
