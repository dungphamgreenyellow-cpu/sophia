(async ()=>{
  try{
    const res = await fetch('http://localhost:8080/api/dashboard');
    const t = await res.text();
    console.log(t);
  } catch(e) { console.error(e); process.exit(1); }
})();