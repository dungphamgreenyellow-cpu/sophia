const express = require('express');
const router = express.Router();
const db = require('../db');
const { v4: uuidv4 } = require('uuid');

function lastNameFrom(full) {
  if (!full) return '';
  const parts = full.trim().split(/\s+/);
  return parts[parts.length-1];
}

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM teachers ORDER BY last_name COLLATE NOCASE ASC').all();
  res.json({ success: true, data: rows });
});

router.post('/', (req, res) => {
  const id = uuidv4();
  const p = req.body;
  const last_name = lastNameFrom(p.full_name);
  db.prepare('INSERT INTO teachers (id, full_name, last_name, dob, phone, start_date, status) VALUES (?,?,?,?,?,?,?)')
    .run(id, p.full_name, last_name, p.dob, p.phone||'', p.start_date||'', p.status||'active');
  res.json({ success: true, id });
});

router.put('/:id', (req, res) => {
  const id = req.params.id;
  const p = req.body;
  const last_name = lastNameFrom(p.full_name);
  db.prepare('UPDATE teachers SET full_name=?, last_name=?, dob=?, phone=?, start_date=?, status=? WHERE id=?')
    .run(p.full_name, last_name, p.dob, p.phone||'', p.start_date||'', p.status||'active', id);
  res.json({ success: true });
});

module.exports = router;