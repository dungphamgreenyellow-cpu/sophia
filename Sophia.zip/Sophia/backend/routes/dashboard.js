const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req, res) => {
  const classesCount = db.prepare('SELECT COUNT(*) as c FROM classes').get().c;
  const studentsCount = db.prepare('SELECT COUNT(*) as c FROM students WHERE status = "active"').get().c;
  const teachersCount = db.prepare('SELECT COUNT(*) as c FROM teachers WHERE status = "active"').get().c;

  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth()+1).padStart(2,'0');
  const monthPrefix = `${y}-${m}`;
  const joined = db.prepare('SELECT COUNT(*) as c FROM students WHERE enroll_date LIKE ?').get(`${monthPrefix}%`).c;
  const left = db.prepare('SELECT COUNT(*) as c FROM students WHERE exit_date LIKE ?').get(`${monthPrefix}%`).c;

  const totalThu = db.prepare('SELECT SUM(amount) as s FROM ledger WHERE amount > 0').get().s || 0;
  const totalChi = db.prepare('SELECT SUM(amount) as s FROM ledger WHERE amount < 0').get().s || 0;
  const profit = totalThu + totalChi;

  res.json({ success: true, data: {
    classesCount, studentsCount, teachersCount,
    joined, left,
    totalThu, totalChi, profit
  }});
});

module.exports = router;