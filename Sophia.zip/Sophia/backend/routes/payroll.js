const express = require('express');
const router = express.Router();
const db = require('../db');

// GET payroll by month (YYYY-MM)
router.get('/', (req, res) => {
  const month = req.query.month || (new Date()).toISOString().slice(0,7);
  const rows = db.prepare('SELECT * FROM payroll WHERE month = ?').all(month);
  res.json({ success: true, data: rows });
});

// Upsert payroll item and sync ledger
router.put('/:id', (req, res) => {
  const id = req.params.id;
  const p = req.body;
  const exists = db.prepare('SELECT * FROM payroll WHERE id = ?').get(id);
  if (exists) {
    db.prepare('UPDATE payroll SET teacher_id=?, month=?, basic=?, allowance=?, bonus=?, deduction=?, overtime=?, other=?, net=? WHERE id=?')
      .run(p.teacher_id, p.month, p.basic||0, p.allowance||0, p.bonus||0, p.deduction||0, p.overtime||0, p.other||0, p.net||0, id);
  } else {
    db.prepare('INSERT INTO payroll (id, teacher_id, month, basic, allowance, bonus, deduction, overtime, other, net) VALUES (?,?,?,?,?,?,?,?,?,?)')
      .run(id, p.teacher_id, p.month, p.basic||0, p.allowance||0, p.bonus||0, p.deduction||0, p.overtime||0, p.other||0, p.net||0);
  }
  const cat = 'Chi lương';
  const amount = -(p.net||0);
  const linked = db.prepare('SELECT * FROM ledger WHERE payroll_item_id = ?').get(id);
  if (linked) {
    db.prepare('UPDATE ledger SET date=?, type=?, category=?, amount=?, note=? WHERE id=?')
      .run((new Date()).toISOString(), 'chi', cat, amount, `Payroll ${id}`, linked.id);
  } else {
    const ledgerId = require('uuid').v4();
    db.prepare('INSERT INTO ledger (id, date, type, category, amount, note, payroll_item_id) VALUES (?,?,?,?,?,?,?)')
      .run(ledgerId, (new Date()).toISOString(), 'chi', cat, amount, `Payroll ${id}`, id);
  }
  res.json({ success: true });
});

module.exports = router;
