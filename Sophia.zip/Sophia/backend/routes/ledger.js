const express = require('express');
const router = express.Router();
const db = require('../db');
const { v4: uuidv4 } = require('uuid');

// list ledger (newest first)
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM ledger ORDER BY date DESC, id DESC').all();
  res.json({ success: true, data: rows });
});

router.post('/', (req, res) => {
  const { date, type, category, amount, note, payroll_item_id } = req.body;
  const id = uuidv4();
  const signed = type === 'chi' ? -Math.abs(amount) : Math.abs(amount);
  db.prepare('INSERT INTO ledger (id, date, type, category, amount, note, payroll_item_id) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(id, date, type, category, signed, note || '', payroll_item_id || null);
  res.json({ success: true, id });
});

router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { date, type, category, amount, note } = req.body;
  const signed = type === 'chi' ? -Math.abs(amount) : Math.abs(amount);
  db.prepare('UPDATE ledger SET date=?, type=?, category=?, amount=?, note=? WHERE id=?')
    .run(date, type, category, signed, note || '', id);
  res.json({ success: true });
});

router.delete('/:id', (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM ledger WHERE id=?').run(id);
  res.json({ success: true });
});

module.exports = router;
