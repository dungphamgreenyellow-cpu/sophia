const express = require('express');
const router = express.Router();
const db = require('../db');
const { v4: uuidv4 } = require('uuid');

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM classes ORDER BY name COLLATE NOCASE ASC').all();
  const enriched = rows.map(r => {
    let teacher_ids = [];
    try { teacher_ids = JSON.parse(r.teacher_ids || '[]'); } catch(e) { teacher_ids = []; }
      const count = db.prepare('SELECT COUNT(*) as c FROM students WHERE status = "active" AND class_id = ?').get(r.id).c;
    return { ...r, teacher_ids, size: count };
  });
  res.json({ success: true, data: enriched });
});

router.post('/', (req, res) => {
  const id = uuidv4();
  const { name, teacher_ids } = req.body;
  db.prepare('INSERT INTO classes (id, name, teacher_ids) VALUES (?, ?, ?)').run(id, name, JSON.stringify(teacher_ids||[]));
  res.json({ success: true, id });
});

router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { name, teacher_ids } = req.body;
  db.prepare('UPDATE classes SET name=?, teacher_ids=? WHERE id=?').run(name, JSON.stringify(teacher_ids||[]), id);
  res.json({ success: true });
});

router.get('/:id/students', (req, res) => {
  const { id } = req.params;
  const rows = db.prepare('SELECT * FROM students WHERE class_id = ? ORDER BY last_name COLLATE NOCASE ASC').all(id);
  res.json({ success: true, data: rows });
});

module.exports = router;