const express = require('express');
const router = express.Router();
const db = require('../db');
const { v4: uuidv4 } = require('uuid');

function lastNameFrom(full) {
  if (!full) return '';
  const parts = full.trim().split(/\s+/);
  return parts[parts.length-1];
}

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM students ORDER BY last_name COLLATE NOCASE ASC').all();
  res.json({ success: true, data: rows });
});

router.post('/', (req, res) => {
  const id = uuidv4();
  const payload = req.body;
  const last_name = lastNameFrom(payload.full_name);
  db.prepare(`INSERT INTO students (id, full_name, last_name, dob, enroll_date, exit_date, class_id, status, parent1_name, parent1_relation, parent1_phone, parent1_address, parent2_name, parent2_relation, parent2_phone, parent2_address) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, payload.full_name, last_name, payload.dob, payload.enroll_date, payload.exit_date || null, payload.class_id||null, payload.status || 'active', payload.parent1_name||'', payload.parent1_relation||'', payload.parent1_phone||'', payload.parent1_address||'', payload.parent2_name||'', payload.parent2_relation||'', payload.parent2_phone||'', payload.parent2_address||'');
  res.json({ success: true, id });
});

router.put('/:id', (req, res) => {
  const { id } = req.params;
  const payload = req.body;
  const last_name = lastNameFrom(payload.full_name);
  db.prepare('UPDATE students SET full_name=?, last_name=?, dob=?, enroll_date=?, exit_date=?, class_id=?, status=?, parent1_name=?, parent1_relation=?, parent1_phone=?, parent1_address=?, parent2_name=?, parent2_relation=?, parent2_phone=?, parent2_address=? WHERE id=?')
    .run(payload.full_name, last_name, payload.dob, payload.enroll_date, payload.exit_date||null, payload.class_id||null, payload.status||'active', payload.parent1_name||'', payload.parent1_relation||'', payload.parent1_phone||'', payload.parent1_address||'', payload.parent2_name||'', payload.parent2_relation||'', payload.parent2_phone||'', payload.parent2_address||'', id);
  res.json({ success: true });
});

module.exports = router;