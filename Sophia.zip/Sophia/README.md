SOPHIA — Kindergarten Admin System

Local dev:
- Frontend: http://localhost:3000
- Backend:  http://localhost:8080

Login: admin / admin123

Run:
1) BACKEND: cd backend && npm i && npm run seed && npm run dev
2) FRONTEND: cd frontend && npm i && npm run dev
